//---------------------------------------------------------------------------
// Header Guard
#pragma once

// Includes and Namespaces
#include <windows.h>
#include <regex>
#include <Strsafe.h>
#include <string>
#include "CoreKMS.h"

// Function Prototypes
void GetKMSHWID(PQWORD KMSHWID, REQUEST* const Request);
//---------------------------------------------------------------------------