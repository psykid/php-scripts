//---------------------------------------------------------------------------
// Header Guard
#pragma once

// Includes and Namespaces
#include "KMSClientLogic.h"