//---------------------------------------------------------------------------
// Header Guard
#pragma once

// Includes and Namespaces
#include "KMSServerLogic.h"