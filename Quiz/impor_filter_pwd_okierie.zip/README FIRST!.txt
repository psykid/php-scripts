--------PANDUAN INSTALASI-----------------------------------------
Pertama buat database dengan nama "data". 
Kemudian buat tabel "karyawan" dengan field :
"ID"(int ,11,primary key,auto increment), 
"Nama"(varchar,50), 
dan "TglLahir"(date).

Ekstrak file  "impor_filter.zip", 

UNTUK PENGGUNA WINDOWS:
sesuaikan/atur ulang host, username, dan password mysql di file koneksi.php

copy dan paste folder "impor_filter" ke folder htdocs.
Buka browser ketikan alamat "localhost/impor_filter".
Impor file "data_update.xls" dengan cara : 
klik tombol/form "pilih file"/"choose file"/"browse.." 
kemudian pilih file"data_update.xls" 
yang berada di folder "impor_filter", Klik tombol "Import".

(form import ini ada di bagian paling atas dokumen, background merah).
Setelah proses selesai, tekan f5 atau refresh.

Jadikan ini sebagai referensi saja! :D
-------------------------------------------------------------------
paket fungsi : 
create pdf (menggunakan class mdf versi 5.4)
print melalui pdf reader
import *.xls ke sql (dengan metode "insert" ke database sql)
filter nama
filter "tanggal" dari type data "date" dalam sql
filter "bulan" dari type data "date" dalam sql
filter "tahun" dari type data "date" dalam sql
--------------------------------------------------------------------
PASSWORD : okierie
--------------------------------------------------------------------
regards,

^_^

okierie
